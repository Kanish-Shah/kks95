#Loading Data Set# 
setwd("C:/Users/dell/Desktop/CS 513")
mydata = read.csv("attrition_data.csv")

#Unfactorizing data to edit#
library(varhandle)
mydata=unfactor(mydata)

#Changing characters to integers#
mydata[mydata == "AMIND"] <- '1'
mydata[mydata == "ASIAN"] <- '2'
mydata[mydata == "BLACK"] <- '3'
mydata[mydata == "HISPA"] <- '4'
mydata[mydata == "PACIF"] <- '5'
mydata[mydata == "TWO"] <- '6'
mydata[mydata == "WHITE"] <- '7'
mydata[mydata == "F"] <- '1'
mydata[mydata == "M"] <- '2'
mydata[mydata == "Divorced"] <- '1'
mydata[mydata == "Married"] <- '2'
mydata[mydata == "Single"] <- '3'
mydata[mydata == "3+"] <- '4'
mydata[mydata == "FALSE"] <- '1'
mydata[mydata == "TRUE"] <- '2'
mydata[mydata == "N"] <- '1'
mydata[mydata == "Y"] <- '2'
mydata[mydata == "LEVEL 1"] <- '1'
mydata[mydata == "LEVEL 2"] <- '2'
mydata[mydata == "LEVEL 3"] <- '3'
mydata[mydata == "LEVEL 4"] <- '4'
mydata[mydata == "LEVEL 5"] <- '5'
mydata[mydata == "A"] <- '1'
mydata[mydata == "T"] <- '2'
mydata[mydata == "January"] <- '1'
mydata[mydata == "February"] <- '2'
mydata[mydata == "March"] <- '3'
mydata[mydata == "April"] <- '4'
mydata[mydata == "May"] <- '5'
mydata[mydata == "June"] <- '6'
mydata[mydata == "July"] <- '7'
mydata[mydata == "August"] <- '8'
mydata[mydata == "September"] <- '9'
mydata[mydata == "October"] <- '10'
mydata[mydata == "November"] <- '11'
mydata[mydata == "December"] <- '12'
mydata[mydata == "Accounting"] <- '1'
mydata[mydata == "Accounts Payable"] <- '2'
mydata[mydata == "Advanced Research"] <- '3'
mydata[mydata == "Analytical/Microbiology"] <- '4'
mydata[mydata == "Applied Research"] <- '5'
mydata[mydata == "Brand Operations"] <- '6'
mydata[mydata == "Claims Substantiation"] <- '7'
mydata[mydata == "Corporate Supply Chain"] <- '8'
mydata[mydata == "Creative Service/Copy"] <- '9'
mydata[mydata == "Customer Care"] <- '10'
mydata[mydata == "Customer Relationship Mgmt"] <- '11'
mydata[mydata == "Demand Planning"] <- '12'
mydata[mydata == "Demi-Grand"] <- '13'
mydata[mydata == "Digital"] <- '14'
mydata[mydata == "Distribution/Administration"] <- '15'
mydata[mydata == "eCommerce"] <- '16'
mydata[mydata == "Engineering"] <- '17'
mydata[mydata == "Finance"] <- '18'
mydata[mydata == "Flows & Sub-Contracting"] <- '19'
mydata[mydata == "General Administration"] <- '20'
mydata[mydata == "General Management"] <- '21'
mydata[mydata == "Human Resources"] <- '22'
mydata[mydata == "Industrial Quality"] <- '23'
mydata[mydata == "Insurance & Risk Management"] <- '24'
mydata[mydata == "Integrated Marketing Comm"] <- '25'
mydata[mydata == "Integrated Mktg Communications"] <- '26'
mydata[mydata == "Intellectual Proprty & Patents"] <- '27'
mydata[mydata == "IT Architecture and Integrtion"] <- '28'
mydata[mydata == "IT Business Applications"] <- '29'
mydata[mydata == "IT Digital"] <- '30'
mydata[mydata == "IT Governance and Management"] <- '31'
mydata[mydata == "IT Security/Risk and Quality"] <- '32'
mydata[mydata == "IT Technologies and Infrstrctr"] <- '33'
mydata[mydata == "Legal"] <- '34'
mydata[mydata == "Logistics - Distribution"] <- '35'
mydata[mydata == "Logistics - Manufacturing"] <- '36'
mydata[mydata == "Manufacturing Supply Chain"] <- '37'
mydata[mydata == "Market Research"] <- '38'
mydata[mydata == "Market Supply Logistics"] <- '39'
mydata[mydata == "Marketing - Direct"] <- '40'
mydata[mydata == "Marketing - Global"] <- '41'
mydata[mydata == "Marketing Support/Services"] <- '42'
mydata[mydata == "Multi-Channel"] <- '43'
mydata[mydata == "Package Development"] <- '44'
mydata[mydata == "Physical Flows"] <- '45'
mydata[mydata == "Plant & Facilities Maintenance"] <- '46'
mydata[mydata == "Plant Management"] <- '47'
mydata[mydata == "Prod Planning & Inventory Ctl"] <- '48'
mydata[mydata == "Production & Operations"] <- '49'
mydata[mydata == "Promotional Purchasing"] <- '50'
mydata[mydata == "Public Relations"] <- '51'
mydata[mydata == "Quality Assurance"] <- '52'
mydata[mydata == "R&I Development/Pre-Develpmnt"] <- '53'
mydata[mydata == "R&I Evaluation"] <- '54'
mydata[mydata == "R&I General Management"] <- '55'
mydata[mydata == "R&I Safety Evaluation"] <- '56'
mydata[mydata == "Regulatory Affairs"] <- '57'
mydata[mydata == "Social Media"] <- '58'
mydata[mydata == "Sourcing"] <- '59'
mydata[mydata == "Supply Chain Administration"] <- '60'
mydata[mydata == "Supply Chain Finance"] <- '61'
mydata[mydata == "Tax"] <- '62'
mydata[mydata == "Technical Packaging"] <- '63'
mydata[mydata == "Transportation & Warehousing"] <- '64'
mydata[mydata == "Treasury"] <- '65'
mydata[mydata == "Web"] <- '66'

mydata$ETHNICITY <- as.numeric(mydata$ETHNICITY)    
mydata$SEX <- as.numeric(mydata$SEX)  
mydata$MARITAL_STATUS <- as.numeric(mydata$MARITAL_STATUS)  
mydata$NUMBER_OF_TEAM_CHANGED <- as.numeric(mydata$NUMBER_OF_TEAM_CHANGED)  
mydata$HIRE_MONTH<- as.numeric(mydata$HIRE_MONTH) 
mydata$REHIRE <- as.numeric(mydata$REHIRE)  
mydata$IS_FIRST_JOB <- as.numeric(mydata$IS_FIRST_JOB)  
mydata$TRAVELLED_REQUIRED <- as.numeric(mydata$TRAVELLED_REQUIRED)  
mydata$DISABLED_EMP <- as.numeric(mydata$DISABLED_EMP)
mydata$DISABLED_VET <- as.numeric(mydata$DISABLED_VET)  
mydata$EDUCATION_LEVEL <- as.numeric(mydata$EDUCATION_LEVEL)  
mydata$STATUS <- as.numeric(mydata$STATUS)  
mydata$JOB_GROUP <- as.numeric(mydata$JOB_GROUP)  

#Creating a new dataset#
library(dplyr)
mydata2 <- select(mydata,ANNUAL_RATE,HRLY_RATE,AGE,ETHNICITY,SEX,MARITAL_STATUS,JOB_SATISFACTION,NUMBER_OF_TEAM_CHANGED,
                  HIRE_MONTH,REHIRE,IS_FIRST_JOB,TRAVELLED_REQUIRED,PERFORMANCE_RATING,DISABLED_EMP,DISABLED_VET, 
                  EDUCATION_LEVEL,STATUS,JOB_GROUP,PREVYR_1,PREVYR_2,PREVYR_3,PREVYR_4,PREVYR_5)

#Normalizing continuous variables#
mydata3 <- mydata2 %>% mutate_at(1:3, funs((.-min(.))/max(.-min(.))))

#Removing missing values#
mydata4<-na.omit(mydata3)

#Creating a new csv file to use dataset for SAs#
write.csv(mydata4,"mydata4.csv")
