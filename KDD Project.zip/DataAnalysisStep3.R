#Loading Data Set# 
setwd("C:/Users/dell/Desktop/CS 513")
mydata = read.csv("attrition_data.csv")
View(mydata)
library(varhandle)
sapply(mydata,class)
summary(mydata)

#Scatter Plot#
pairs(~ AGE + ANNUAL_RATE,data = mydata, pch=1) 

#Histogram#                       
hist(mydata$ANNUAL_RATE)

#Removing outliers found from proc univariate analysis on SAS#
mydata<-mydata[which(mydata$ANNUAL_RATE<215000),]

#Factorizing variables#
mydata$PREVYR_1 <- as.factor(mydata$PREVYR_1)
mydata$PREVYR_2 <- as.factor(mydata$PREVYR_2)
mydata$PREVYR_3 <- as.factor(mydata$PREVYR_3)
mydata$PREVYR_4 <- as.factor(mydata$PREVYR_4)
mydata$PREVYR_5 <- as.factor(mydata$PREVYR_5)

#Creating a new dataframe only with significant variables found from Stepwise p value analysis on SAS#
set.seed(555)
library(dplyr)
mydata2 <- select(mydata,ANNUAL_RATE,AGE,JOB_GROUP,STATUS,PREVYR_1,PREVYR_2,PREVYR_3,PREVYR_4,PREVYR_5)

#Normalizing continuous variables# 
mydata3 <- mydata2 %>% mutate_at(1:2, funs((.-min(.))/max(.-min(.))))

#Removing missing values# 
mydata5<-na.omit(mydata3) 

#Forming training and test data sets#
idx1<-sort(sample(nrow(mydata5),as.integer(.70*nrow(mydata5))))  
training<-mydata5[idx1,]
test<-mydata5[-idx1,]

#Getting kknn ready for machine learning#
library(kknn)

#Results for k=10# 
predict1_k10 <- kknn(formula=STATUS~., training, test[,-4], k=10,kernel ="triangular" )
fit3 <- fitted(predict1_k10)
table(actual=test$STATUS,knn=fit3)

#Accuracy Rate#
error1<-(test[,4]!=fit3)
knn_accuracy_rate<-1-(sum(error1)/length(test[,4]))
knn_accuracy_rate 

#Getting Naive Bayes ready for machine learning#
library(e1071)

#Naive Bayes classification using all variables#
nBayes_all<-naiveBayes(STATUS ~.,data=training)
category_all<-predict(nBayes_all,test)

#Confusion matrix# 
table(actual=test$STATUS,NB=category_all)  

#Accuracy Rate#
error2<-(test[,4]!=category_all)
NB_accuracy_rate<-1-(sum(error2)/length(test[,4]))
NB_accuracy_rate  

#Getting C5.0 ready for machine learning#
library('C50')
C50_class <- C5.0(STATUS~.,data=training, trials = 3,control=C5.0Control(fuzzyThreshold = TRUE))
C50_predict<-predict( C50_class ,test , type="class" )

#Confusion Matrix#
table(actual=test[,4],C50=C50_predict)      

#Accuracy Rate#
error<-(test[,4]!=C50_predict)
c50_accuracy_rate<-1-(sum(error)/length(test[,4]))
c50_accuracy_rate                                        
